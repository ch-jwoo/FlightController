//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: FW_att_control_codeblock_fly_types.h
//
// Code generated for Simulink model 'FW_att_control_codeblock_fly'.
//
// Model version                  : 1.52
// Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
// C/C++ source code generated on : Fri Oct  2 16:09:59 2020
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_FW_att_control_codeblock_fly_types_h_
#define RTW_HEADER_FW_att_control_codeblock_fly_types_h_

// Model Code Variants
#endif                      // RTW_HEADER_FW_att_control_codeblock_fly_types_h_

//
// File trailer for generated code.
//
// [EOF]
//
